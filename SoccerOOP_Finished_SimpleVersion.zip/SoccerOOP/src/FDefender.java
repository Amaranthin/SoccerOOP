import java.util.Random;

public class FDefender extends Footballer{

    public FDefender()
    {
        super("DEF");
    }

}
