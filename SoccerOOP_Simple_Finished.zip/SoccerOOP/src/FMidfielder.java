public class FMidfielder extends Footballer{

    public FMidfielder()
    {
        super("MID");
    }
}
